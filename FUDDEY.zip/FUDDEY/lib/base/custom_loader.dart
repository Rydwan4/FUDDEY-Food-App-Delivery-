import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../Controllers/c_auth_controller.dart';
import '../komponen/k_dimensi.dart';
import '../komponen/k_warna.dart';

class CustomLoader extends StatelessWidget {
  const CustomLoader({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        height: Dimensi.height20*5,
        width: Dimensi.width20*5,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(Dimensi.height20*5/2),
          color: WarnaL.warnautama
        ),
        alignment: Alignment.center,
        child: CircularProgressIndicator(color: Colors.white)
      ),
    );
  }
}
