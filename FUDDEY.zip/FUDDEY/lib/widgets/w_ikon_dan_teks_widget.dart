import 'package:flutter/cupertino.dart';
import 'package:tubes/komponen/k_dimensi.dart';
import 'package:tubes/widgets/w_teks_kecil.dart';

class IkonDanTeksWidget extends StatelessWidget {
  final IconData ikon;
  final String teks;
  final Color ikonwarna;
  const IkonDanTeksWidget({Key? key,
    required this.ikon,
    required this.teks,
    required this.ikonwarna}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(ikon, color: ikonwarna, size: Dimensi.icon24),
        SizedBox(width: 5),
        TeksKecil(text: teks),
      ]
    );
  }
}
