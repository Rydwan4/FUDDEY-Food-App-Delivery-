import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tubes/komponen/k_dimensi.dart';
import 'package:tubes/komponen/k_warna.dart';
import 'package:tubes/widgets/w_teks_kecil.dart';

class ShowMoreTeks extends StatefulWidget {
  final String text;
  const ShowMoreTeks({Key? key, required this.text}) : super(key: key);

  @override
  State<ShowMoreTeks> createState() => _ShowMoreTeksState();
}

class _ShowMoreTeksState extends State<ShowMoreTeks> {
  late String setengahawal;
  late String setengahakhir;

  bool tekstersembunyi = true;
  double teksheight = Dimensi.screenHeight/5.35;

  @override
  void initState(){
    super.initState();
    if(widget.text.length>teksheight){
      setengahawal = widget.text.substring(0, teksheight.toInt());
      setengahakhir = widget.text.substring(teksheight.toInt()+1, widget.text.length);
    }
    else{
      setengahawal=widget.text;
      setengahakhir="";
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: setengahakhir.isEmpty?TeksKecil(size: Dimensi.font16, text: setengahawal):Column(
        children: [
          TeksKecil(height:1.4, color: WarnaL.warnapara,size: Dimensi.font16, text: tekstersembunyi?(setengahawal+"..."):setengahawal+setengahakhir),
          InkWell(
            onTap: (){
              setState(() {
                tekstersembunyi=!tekstersembunyi;
              });
            },
            child: Row(
              children: [
                TeksKecil(text: "Kepo Ya", color: WarnaL.warnautama, size: Dimensi.font16),
                Icon(tekstersembunyi?Icons.arrow_drop_down:Icons.arrow_drop_up, color: WarnaL.warnautama),
              ]
            ),
          )
        ]
      ),
    );
  }
}
