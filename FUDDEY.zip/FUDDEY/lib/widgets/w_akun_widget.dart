import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tubes/widgets/w_ikon_aplikasi.dart';
import 'package:tubes/widgets/w_teks_besar.dart';

import '../komponen/k_dimensi.dart';

class AkunWidget extends StatelessWidget {
  IkonAplikasi ikonAplikasi;
  TeksBesar teksBesar;
  AkunWidget({Key? key, required this.ikonAplikasi, required this.teksBesar}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(
          left: Dimensi.width20,
          top: Dimensi.height10,
          bottom: Dimensi.height10
      ),
      child: Row(
        children: [
          ikonAplikasi,
          SizedBox(width: Dimensi.width20),
          teksBesar
        ]
      ),
      decoration: BoxDecoration(
          color: Colors.white,
        boxShadow: [
          BoxShadow(
            blurRadius: 1,
            offset: Offset(0,2),
            color: Colors.grey.withOpacity(0.2),
          )
        ]
      )
    );
  }
}
