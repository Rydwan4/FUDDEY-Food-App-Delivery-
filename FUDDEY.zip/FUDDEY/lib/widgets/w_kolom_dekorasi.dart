import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tubes/widgets/w_teks_besar.dart';
import 'package:tubes/widgets/w_teks_kecil.dart';

import '../komponen/k_dimensi.dart';
import '../komponen/k_warna.dart';
import 'w_ikon_dan_teks_widget.dart';

class KolomDekorasi extends StatelessWidget {
  final String teks;
  const KolomDekorasi({Key? key, required this.teks}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TeksBesar(text: teks),
        SizedBox(height: Dimensi.height10),
        Row(
            children: [
              Wrap(
                  children: List.generate(5, (index) => Icon(Icons.star, color: WarnaL.warnautama, size: 15))
              ),
              SizedBox(width: 10),
              TeksKecil(text: "4.5"),
              SizedBox(width: 10),
              TeksKecil(text: "1287"),
              SizedBox(width: 10),
              TeksKecil(text: "Comments")
            ]
        ),
        SizedBox(height: Dimensi.height20),
        Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IkonDanTeksWidget(ikon: Icons.circle_sharp,
                  teks: "Normal",
                  ikonwarna: WarnaL.warnaicon1
              ),
              IkonDanTeksWidget(ikon: Icons.location_on,
                  teks: "1,7km",
                  ikonwarna: WarnaL.warnaicon3
              ),
              IkonDanTeksWidget(ikon: Icons.access_time_rounded,
                  teks: "32min",
                  ikonwarna: WarnaL.warnaicon2
              ),
            ]
        )
      ],
    );
  }
}
