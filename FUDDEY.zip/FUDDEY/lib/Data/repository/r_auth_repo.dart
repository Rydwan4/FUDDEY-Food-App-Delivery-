import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tubes/model/signup_body_model.dart';

import '../../komponen/k_aplikasi_konstan.dart';
import '../API/api_client.dart';

class AuthRepo{
  final ApiClient apiClient;
  final SharedPreferences sharedPreferences;
  AuthRepo({required this.apiClient, required this.sharedPreferences});

  Future<Response> registrasi(SignUpBody signUpBody)async{
    return await apiClient.postData(AplikasiKonstan.REGISTRASI_URI, signUpBody.toJson());
  }

  Future<String> getUserToken()async{
    return await sharedPreferences.getString(AplikasiKonstan.TOKEN)??"None";
  }

  bool userLoggedIn(){
    return sharedPreferences.containsKey(AplikasiKonstan.TOKEN);
  }

  Future<Response> login(String email, String password)async{
    return await apiClient.postData(AplikasiKonstan.LOGIN_URI, {"email":email, "password": password});
  }

  Future<bool> saveUserToken(String token)async{
    apiClient.token = token;
    apiClient.updateHeader(token);
    return await sharedPreferences.setString(AplikasiKonstan.TOKEN, token);
  }

  Future<void> saveUserNumberAndPassword(String number, String password) async {
    try{
      await sharedPreferences.setString(AplikasiKonstan.PHONE, number);
      await sharedPreferences.setString(AplikasiKonstan.PASSWORD, password);
    }catch(e){
      throw e;
    }
  }
}