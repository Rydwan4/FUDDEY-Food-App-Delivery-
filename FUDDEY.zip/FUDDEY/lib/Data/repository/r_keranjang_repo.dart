import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
import 'package:tubes/komponen/k_aplikasi_konstan.dart';

import '../../model/keranjang_model.dart';

class KeranjangRepo{
  final SharedPreferences sharedPreferences;
  KeranjangRepo({required this.sharedPreferences});

  List<String> keranjang=[];
  List<String> keranjangHistory=[];

  void tambahKeranjangList(List<KeranjangModel> keranjangList){
    /*sharedPreferences.remove(AplikasiKonstan.KERANJANG_HISTORY_LIST);
    sharedPreferences.remove(AplikasiKonstan.KERANJANG_LIST);
    return;*/
    var time = DateTime.now().toString();
    keranjang=[];

    keranjangList.forEach((element) {
      element.time = time;
      return keranjang.add(jsonEncode(element));
    });

    sharedPreferences.setStringList(AplikasiKonstan.KERANJANG_LIST, keranjang);
    //print(sharedPreferences.getStringList(AplikasiKonstan.KERANJANG_LIST));
    //getKeranjangList();
  }

  List<KeranjangModel> getKeranjangList(){
    List<String> keranjangs=[];
    if(sharedPreferences.containsKey(AplikasiKonstan.KERANJANG_LIST)){
      keranjangs = sharedPreferences.getStringList(AplikasiKonstan.KERANJANG_LIST)!;

    }
    List<KeranjangModel> keranjangList=[];

    keranjangs.forEach((element) => keranjangList.add(KeranjangModel.fromJson(jsonDecode(element))));

    return keranjangList;
  }

  List<KeranjangModel> getKeranjangHistoryList(){
    if(sharedPreferences.containsKey(AplikasiKonstan.KERANJANG_HISTORY_LIST)){
      keranjangHistory=[];
      keranjangHistory= sharedPreferences.getStringList(AplikasiKonstan.KERANJANG_HISTORY_LIST)!;
    }
    List<KeranjangModel> keranjangListHistory=[];
    keranjangHistory.forEach((element) => keranjangListHistory.add(KeranjangModel.fromJson(jsonDecode(element))));
    return keranjangListHistory;
  }

  void tambahKeKeranjangHistoryList(){
    if(sharedPreferences.containsKey(AplikasiKonstan.KERANJANG_HISTORY_LIST)){
      keranjangHistory = sharedPreferences.getStringList(AplikasiKonstan.KERANJANG_HISTORY_LIST)!;
    }
    for(int i=0; i<keranjang.length; i++){
      //print("history list "+keranjang[i]);
    keranjangHistory.add(keranjang[i]);
    }
    removeKeranjang();
    sharedPreferences.setStringList(AplikasiKonstan.KERANJANG_HISTORY_LIST, keranjangHistory);
    //print("The length of history list is "+getKeranjangList().length.toString());
    for(int i=0; i<getKeranjangHistoryList().length; i++){
      print("The time for the order is "+getKeranjangHistoryList()[i].time.toString());
    }
  }

  void removeKeranjang(){
    keranjang=[];
    sharedPreferences.remove(AplikasiKonstan.KERANJANG_LIST);
  }

}