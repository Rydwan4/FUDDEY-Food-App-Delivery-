import 'package:get/get.dart';
import '../../komponen/k_aplikasi_konstan.dart';
import '../API/api_client.dart';

class ProdukRekomendasiRepo extends GetxService{
  final ApiClient apiClient;
  ProdukRekomendasiRepo({required this.apiClient});

  Future<Response> getProdukRekomendasiList() async{
    return await apiClient.getData(AplikasiKonstan.RECOMMENDED_PRODUCT_URI);
  }
}