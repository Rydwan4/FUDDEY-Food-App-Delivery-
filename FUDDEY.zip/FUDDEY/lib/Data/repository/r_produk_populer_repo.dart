import 'package:get/get.dart';
import '../../komponen/k_aplikasi_konstan.dart';
import '../API/api_client.dart';

class ProdukPopulerRepo extends GetxService{
  final ApiClient apiClient;
  ProdukPopulerRepo({required this.apiClient});

  Future<Response> getProdukPopulerList() async{
    return await apiClient.getData(AplikasiKonstan.POPULAR_PRODUCT_URI);
  }
}