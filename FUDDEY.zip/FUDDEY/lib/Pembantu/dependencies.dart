import 'package:shared_preferences/shared_preferences.dart';
import 'package:tubes/Controllers/c_keranjang_controller.dart';
import 'package:tubes/Controllers/c_produk_rekomendasi_controller.dart';
import 'package:tubes/Data/API/api_client.dart';
import 'package:get/get.dart';
import 'package:tubes/Data/repository/r_keranjang_repo.dart';
import 'package:tubes/Data/repository/r_produk_rekomendasi_repo.dart';
import '../Controllers/c_auth_controller.dart';
import '../Controllers/c_produk_populer_controller.dart';
import '../Data/repository/r_auth_repo.dart';
import '../Data/repository/r_produk_populer_repo.dart';
import '../komponen/k_aplikasi_konstan.dart';

Future<void> init()async {
  final sharedPreferences = await SharedPreferences.getInstance();

  Get.lazyPut(() => sharedPreferences);
  //api client
  Get.lazyPut(() => ApiClient(appBaseUrl: AplikasiKonstan.BASE_URL));
  Get.lazyPut(() => AuthRepo(apiClient: Get.find(), sharedPreferences: Get.find()));

  //repos
  Get.lazyPut(() => ProdukRekomendasiRepo(apiClient: Get.find()));
  Get.lazyPut(() => ProdukPopulerRepo(apiClient: Get.find()));
  Get.lazyPut(() => KeranjangRepo(sharedPreferences:Get.find()));

  //controllers
  Get.lazyPut(() => AuthController(authRepo : Get.find()));
  Get.lazyPut(() => ProdukRekomendasiController(produkRekomendasiRepo: Get.find()));
  Get.lazyPut(() => ProdukPopulerController(produkPopulerRepo: Get.find()));
  Get.lazyPut(() => KeranjangController(keranjangRepo: Get.find()));
}