import 'package:get/get.dart';
import 'package:tubes/Data/repository/r_produk_rekomendasi_repo.dart';
import '../Data/repository/r_produk_populer_repo.dart';
import '../model/model_produk.dart';

class ProdukPopulerController extends GetxController{
  final ProdukPopulerRepo produkPopulerRepo;
  ProdukPopulerController({required this.produkPopulerRepo});
  List<ModelProduk> _produkPopulerList=[];
  List<ModelProduk> get produkPopulerList => _produkPopulerList;

  bool _isLoaded = false;
  bool  get isLoaded => _isLoaded;

  Future<void> getProdukPopulerList()async {
    Response response = await produkPopulerRepo.getProdukPopulerList();
    if(response.statusCode==200){
      print("berhasil (populer)");
      _produkPopulerList=[];
      _produkPopulerList.addAll(Produk.fromJson(response.body).produk);
      //print(_produkPopulerList);
      _isLoaded = true;
      update();
    }else{
      print("gagal (populer)");
    }
  }
}