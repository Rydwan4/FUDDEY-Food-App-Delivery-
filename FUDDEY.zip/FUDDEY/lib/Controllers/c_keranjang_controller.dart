import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tubes/Data/repository/r_keranjang_repo.dart';
import 'package:tubes/model/model_produk.dart';

import '../komponen/k_warna.dart';
import '../model/keranjang_model.dart';

class KeranjangController extends GetxController{
  final KeranjangRepo keranjangRepo;
  KeranjangController({required this.keranjangRepo});

  Map<int, KeranjangModel> _items={};
  Map<int, KeranjangModel> get items=>_items;


  List<KeranjangModel> penyimpananItems=[];
  void addItem(ModelProduk produk, int quantity){
    var totalQuantity=0;
        if (_items.containsKey(produk.id!)) {
          _items.update(produk.id!, (value){
            totalQuantity= value.quantity!+quantity;

            return KeranjangModel(
              id: produk.id,
              name: produk.name,
              price: produk.price,
              img: produk.img,
              quantity: value.quantity!+quantity,
              isExist: true,
              time: DateTime.now().toString(),
              produk: produk,
            );
          });
          if(totalQuantity<=0){
            _items.remove(produk.id);
          }

        }else {
          if(quantity>0){
            _items.putIfAbsent(produk.id!, () {
              return KeranjangModel(
                id: produk.id,
                name: produk.name,
                price: produk.price,
                img: produk.img,
                quantity: quantity,
                isExist: true,
                time: DateTime.now().toString(),
                produk: produk,
              );
            });
          }else{
            Get.snackbar("Peringatan !", "Kamu seharusnya menambahkan setidaknya satu barang !",
              backgroundColor: WarnaL.warnautama,
              colorText: Colors.white,
            );
          }
        }
        keranjangRepo.tambahKeranjangList(getItems);
        update();
  }

  bool inBarangKeranjang(ModelProduk produk){
    if(_items.containsKey(produk.id)){
      return true;
    }
      return false;
  }

  int getQuantity(ModelProduk produk){
    var quantity=0;
    if(_items.containsKey(produk.id)){
      _items.forEach((key, value) {
        if(key==produk.id){
          quantity= value.quantity!;
        }
      });
    }
    return quantity;
  }

  int get totalItems{
    var totalQuantity = 0;
    _items.forEach((key, value) {
      totalQuantity += value.quantity!;
    });
    return totalQuantity;
  }

  List<KeranjangModel> get getItems{
    return _items.entries.map((e){
      return e.value;
    }).toList();
  }

  int get totalAmount{
    var total=0;
      _items.forEach((key, value) {
        total += value.quantity!*value.price!;
      });
    return total;
  }
  List<KeranjangModel> getKeranjangData(){
    setKeranjang = keranjangRepo.getKeranjangList(); 
    return penyimpananItems;
    }

    set setKeranjang(List<KeranjangModel> items){
      penyimpananItems=items;
      
      for(int i=0; i<penyimpananItems.length;i++){
        _items.putIfAbsent(penyimpananItems[i].produk!.id!, () => penyimpananItems[i]);
      }
    }

    void tambahKeHistory(){
      keranjangRepo.tambahKeKeranjangHistoryList();
      clear();
    }

    void clear(){
      _items={};
      update();
    }
    List<KeranjangModel> getKeranjangHistoryList(){
    return keranjangRepo.getKeranjangHistoryList();
    }

    set setItems(Map<int, KeranjangModel> setItems){
        _items={};
        _items =setItems;
      }

    void tambahKeranjangList(){
      keranjangRepo.tambahKeranjangList(getItems);
      update();
    }
}