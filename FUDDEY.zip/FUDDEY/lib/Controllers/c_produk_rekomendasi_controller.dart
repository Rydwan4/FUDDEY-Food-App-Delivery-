import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tubes/Controllers/c_keranjang_controller.dart';
import 'package:tubes/Data/repository/r_produk_rekomendasi_repo.dart';

import '../komponen/k_warna.dart';
import '../model/keranjang_model.dart';
import '../model/model_produk.dart';

class ProdukRekomendasiController extends GetxController{
  final ProdukRekomendasiRepo produkRekomendasiRepo;
  ProdukRekomendasiController({required this.produkRekomendasiRepo});
  List<ModelProduk> _produkRekomendasiList=[];
  List<ModelProduk> get produkRekomendasiList => _produkRekomendasiList;
  late KeranjangController _keranjang;

  bool _isLoaded = false;
  bool  get isLoaded => _isLoaded;

  int _quantity=0;
  int get quantity=>_quantity;
  int _inBarangKeranjang=0;
  int get inBarangKeranjang=>_inBarangKeranjang+_quantity;

  Future<void> getProdukRekomendasiList()async {
    Response response = await produkRekomendasiRepo.getProdukRekomendasiList();
    if(response.statusCode==200){
      print("berhasil (rekomendasi)");
      _produkRekomendasiList=[];
      _produkRekomendasiList.addAll(Produk.fromJson(response.body).produk);
      //print(_produkRekomendasiList);
      _isLoaded = true;
      update();
    }else{
      print("gagal (rekomendasi)");
    }
  }

  void setQuantity(bool isIncrement){
    if(isIncrement){
      _quantity = checkQuantity(_quantity+1);
      //print("numberU "+ _quantity.toString());
    }else{
      _quantity = checkQuantity(_quantity-1);
      //print("numberD "+ _quantity.toString());
    }
    update();
  }

  int checkQuantity(int quantity){
    if((_inBarangKeranjang+quantity)<0){
      Get.snackbar("Peringatan !", "Kamu tidak bisa mengurangiya lagi !",
        backgroundColor: WarnaL.warnautama,
        colorText: Colors.white,
      );
      if(_inBarangKeranjang>0){
        _quantity = _inBarangKeranjang;
        return _quantity;
      }
      return 0;
    }else if((_inBarangKeranjang+quantity)>15){
      Get.snackbar("Peringatan !", "Kamu tidak bisa menambahnya lagi !",
        backgroundColor: WarnaL.warnautama,
        colorText: Colors.white,
      );
      return 15;
    }else{
      return quantity;
    }
  }

  void initProduk(ModelProduk produk, KeranjangController keranjang){
    _quantity=0;
    _inBarangKeranjang=0;
    _keranjang= keranjang;
    var exist=false;
    exist=_keranjang.inBarangKeranjang(produk);
    //print("exist or not "+exist.toString());
    if(exist){
      _inBarangKeranjang=_keranjang.getQuantity(produk);
    }
    print("jumlah di keranjang adalah "+_inBarangKeranjang.toString());
  }

  void addItem(ModelProduk produk){
      _keranjang.addItem(produk, _quantity);
      _quantity=0;
      _inBarangKeranjang=_keranjang.getQuantity(produk);
      _keranjang.items.forEach((key, value) {
        print("The id is "+value.id.toString()+" Jumlahnya adalah "+value.quantity.toString());
      });
    update();
  }

  int get totalItems{
    return _keranjang.totalItems;
  }
  List<KeranjangModel> get getItems {
    return _keranjang.getItems;
  }
}