import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tubes/widgets/w_teks_besar.dart';import '../../Controllers/c_produk_populer_controller.dart';
import '../../Controllers/c_produk_rekomendasi_controller.dart';
import 'package:get/get.dart';


import '../../komponen/k_dimensi.dart';
import '../../komponen/k_warna.dart';
import '../../widgets/w_teks_kecil.dart';
import 'h_halaman_makanan.dart';

class HalamanUtama extends StatefulWidget {
  const HalamanUtama({Key? key}) : super(key: key);

  @override
  State<HalamanUtama> createState() => _HalamanUtamaState();
}

class _HalamanUtamaState extends State<HalamanUtama> {
  Future<void> _loadResource() async {
    await Get.find<ProdukRekomendasiController>().getProdukRekomendasiList();
    await Get.find<ProdukPopulerController>().getProdukPopulerList();
  }

  @override
  Widget build(BuildContext context) {
    //print("current height is "+MediaQuery.of(context).size.height.toString());
    //Keseluruhan
    return RefreshIndicator(
        child: Column(
      children: [
        Container(
          margin: EdgeInsets.only(top: Dimensi.height45, bottom: Dimensi.height15),
          padding: EdgeInsets.only(left: Dimensi.width20, right: Dimensi.width20),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  TeksBesar(text: "Indonesia", color: WarnaL.warnautama),
                  Row(
                      children: [
                        TeksKecil(text: "Surabaya", color: Colors.black54),
                        Icon(Icons.arrow_drop_down_rounded)
                      ]
                  )
                ],
              ),
              Center(
                child: Container(
                  width: Dimensi.height45,
                  height: Dimensi.height45,
                  child: Icon(Icons.search, color:Colors.white, size: Dimensi.icon24),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(Dimensi.radius15),
                    color: WarnaL.warnautama,
                  ),
                ),
              ),
            ],
          ),
        ),
        Expanded(child: SingleChildScrollView(
          child: HalamanMakanan(),
        )),
      ],
    ),
        onRefresh: _loadResource);
  }
}
