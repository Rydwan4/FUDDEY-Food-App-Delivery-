import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tubes/Controllers/c_produk_populer_controller.dart';
import 'package:tubes/Controllers/c_produk_rekomendasi_controller.dart';
import 'package:tubes/Halaman/Makanan/h_detail_makanan_rekomendasi.dart';
import 'package:tubes/model/model_produk.dart';
import 'package:tubes/widgets/w_ikon_dan_teks_widget.dart';
import 'package:tubes/widgets/w_kolom_dekorasi.dart';
import 'package:get/get.dart';
import '../../komponen/k_aplikasi_konstan.dart';
import '../../komponen/k_dimensi.dart';
import '../../komponen/k_warna.dart';
import '../../rute/pembantu_rute.dart';
import '../../widgets/w_teks_besar.dart';
import '../../widgets/w_teks_kecil.dart';

class HalamanMakanan extends StatefulWidget {
  const HalamanMakanan({Key? key}) : super(key: key);

  @override
  State<HalamanMakanan> createState() => _HalamanMakananState();
}

class _HalamanMakananState extends State<HalamanMakanan> {
  PageController pageController = PageController(viewportFraction: 0.9);
  var _currPageValue= 0.0;
  double _scaleFactor= 0.8;
  double _height= Dimensi.pageViewContainer;
  @override
  void initState(){
    super.initState();
    pageController.addListener(() {
      setState(() {
        _currPageValue= pageController.page!;
      });
    });
  }

  @override
  void dispose(){
    pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(

      children: [
        //Teks rekomendasi
        Container(
            alignment: Alignment.centerLeft,
            margin: EdgeInsets.only(left: Dimensi.width30,top: Dimensi.height10, bottom: Dimensi.height10),
            child: TeksBesar(text: "Rekomendasi"),
          ),

        //SLide
        GetBuilder<ProdukRekomendasiController>(builder:(produkRekomendasi){
          return produkRekomendasi.isLoaded?Container(
              height : Dimensi.pageView,
                child: PageView.builder(
                    controller: pageController,
                    itemCount: produkRekomendasi.produkRekomendasiList.length,
                    itemBuilder: (context, position){
                      return _buildPageItem(position, produkRekomendasi.produkRekomendasiList[position]);
                    }),
          ):CircularProgressIndicator(
            color: WarnaL.warnautama,
          );
        }),

        //Dots
        GetBuilder<ProdukRekomendasiController>(builder: (produkRekomendasi){
          return DotsIndicator(
            dotsCount: produkRekomendasi.produkRekomendasiList.isEmpty?1:produkRekomendasi.produkRekomendasiList.length,
            position: _currPageValue,
            decorator: DotsDecorator(
              activeColor: WarnaL.warnautama,
              size: const Size.square(9.0),
              activeSize: const Size(18.0, 9.0),
              activeShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
            ),
          );
        }),

        SizedBox(height: Dimensi.height30),
        //Populer
        Container(
          margin: EdgeInsets.only(left: Dimensi.width30),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              TeksBesar(text: "Populer"),
              SizedBox(width: Dimensi.width10),
              Container(
                margin: const EdgeInsets.only(bottom: 3),
                child: TeksBesar(text: ".",color: Color(0xff888787)),
              ),
              SizedBox(width: Dimensi.width10),
              Container(
                margin: const EdgeInsets.only(bottom: 2),
                child: TeksKecil(text: "Variasi Makanan",)
              )
            ]
          ),
        ),

        //List makanan dan gambar populer
        GetBuilder<ProdukPopulerController>(builder: (produkPopuler){
          return produkPopuler.isLoaded?ListView.builder(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: produkPopuler.produkPopulerList.length,
              itemBuilder: (context, index){
                return GestureDetector(
                  onTap: (){
                    Get.toNamed(PembantuRute.getMakananPopuler(index, "home"));
                  },
                  child: Container(
                      margin: EdgeInsets.only(left: Dimensi.width20, right: Dimensi.width20, bottom: Dimensi.height10),
                      child: Row(
                          children: [
                            //Gambar Container
                            Container(
                              width : Dimensi.listViewImgSize,
                              height : Dimensi.listViewImgSize,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(Dimensi.radius20),
                                  color: Colors.white,
                                  image: DecorationImage(
                                      fit: BoxFit.cover,
                                      image: NetworkImage(
                                          AplikasiKonstan.BASE_URL+AplikasiKonstan.UPLOAD_URL+produkPopuler.produkPopulerList[index].img!
                                      )
                                  )
                              ),
                            ),

                            //Teks Container
                            Expanded(
                              child: Container(
                                  height: Dimensi.listViewTextContSize,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(Dimensi.radius20),
                                      bottomRight: Radius.circular(Dimensi.radius20),
                                    ),
                                  ),
                                  child: Padding(
                                      padding: EdgeInsets.only(left: Dimensi.width10, right: Dimensi.width10),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          TeksBesar(text: produkPopuler.produkPopulerList[index].name!),
                                          SizedBox(height: Dimensi.height10,),
                                          TeksKecil(text: "Dengan karakteristik Suarabaya"),
                                          SizedBox(height: Dimensi.height10,),
                                          Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                IkonDanTeksWidget(ikon: Icons.circle_sharp,
                                                    teks: "Normal",
                                                    ikonwarna: WarnaL.warnaicon1
                                                ),
                                                IkonDanTeksWidget(ikon: Icons.location_on,
                                                    teks: "1,7km",
                                                    ikonwarna: WarnaL.warnautama
                                                ),
                                                IkonDanTeksWidget(ikon: Icons.access_time_rounded,
                                                    teks: "32min",
                                                    ikonwarna: WarnaL.warnaicon2
                                                ),
                                              ]
                                          )
                                        ],
                                      )
                                  )
                              ),
                            )
                          ]
                      )
                  ),
                );
              }):CircularProgressIndicator(
            color: WarnaL.warnautama,
          );
        })
      ]
    );
  }

  Widget _buildPageItem(int index, ModelProduk produkRekomendasi){
    //Perhitungan slide
    Matrix4 matrix = new Matrix4.identity();
    if(index== _currPageValue.floor()){
      var currScale = 1-(_currPageValue-index)*(1-_scaleFactor);
      var currTrans = _height*(1-currScale)/2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1)..setTranslationRaw(0, currTrans, 0);

    }
    else if(index== _currPageValue.floor()+1){
      var currScale = _scaleFactor+(_currPageValue-index+1)*(1-_scaleFactor);
      var currTrans = _height*(1-currScale)/2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1);
      matrix = Matrix4.diagonal3Values(1, currScale, 1)..setTranslationRaw(0, currTrans, 0);

    }
    else if(index== _currPageValue.floor()-1){
      var currScale = 1-(_currPageValue-index)*(1-_scaleFactor);
      var currTrans = _height*(1-currScale)/2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1);
      matrix = Matrix4.diagonal3Values(1, currScale, 1)..setTranslationRaw(0, currTrans, 0);

    }
    else{
      var currScale= 0.8;
      matrix = Matrix4.diagonal3Values(1, currScale, 1)..setTranslationRaw(0, _height*(1-_scaleFactor)/2, 1);
    }

    return Transform(
      transform: matrix,
      //Isi slide
      child: Stack(
        children: [
          //Gambar
          GestureDetector(
            onTap: (){

              Get.toNamed(PembantuRute.getMakananRekomendasi(index, "home"));
            },
            child: Container(
                height: Dimensi.pageViewContainer,
                margin: EdgeInsets.only(left: Dimensi.width10, right: Dimensi.width10),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(Dimensi.radius30),
                    color: index.isEven?Color(0xffffa641):Color(0xffffff41),
                    image: DecorationImage(
                        fit: BoxFit.cover,
                        image: NetworkImage(
                            AplikasiKonstan.BASE_URL+AplikasiKonstan.UPLOAD_URL+produkRekomendasi.img!
                        )
                    )
                )
            ),
          ),
          //Keterangan
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
                height: Dimensi.pageViewTextContainer,
                margin: EdgeInsets.only(left: Dimensi.width30, right: Dimensi.width30, bottom: Dimensi.height30),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(Dimensi.radius20),
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Color(0xFFe8e8e8),
                        blurRadius: 5.0,
                        offset: Offset(0, 5)
                      ),
                      BoxShadow(
                        color: Colors.white,
                        offset: Offset(-5, 0),
                      ),
                      BoxShadow(
                        color: Colors.white,
                        offset: Offset(5, 0),
                      )
                    ]
                ),
              child: Container(
                padding: EdgeInsets.only(top: Dimensi.height15, left: Dimensi.width15, right: Dimensi.width15),
                child: KolomDekorasi(teks: produkRekomendasi.name!),
              ),
            ),
          )
        ]
      ),
    );
  }
}
