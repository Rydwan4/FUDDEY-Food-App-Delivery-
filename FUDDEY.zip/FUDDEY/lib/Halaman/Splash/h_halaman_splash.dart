import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tubes/komponen/k_dimensi.dart';
import 'package:tubes/komponen/k_warna.dart';
import 'package:get/get.dart';
import 'package:tubes/rute/pembantu_rute.dart';

import '../../Controllers/c_produk_populer_controller.dart';
import '../../Controllers/c_produk_rekomendasi_controller.dart';

class HalamanSplash extends StatefulWidget {
  const HalamanSplash({Key? key}) : super(key: key);

  @override
  State<HalamanSplash> createState() => _HalamanSplashState();
}

class _HalamanSplashState extends State<HalamanSplash> with TickerProviderStateMixin{

  late Animation<double> animation;
  late AnimationController controller;

  Future<void> _loadResource() async {
    await Get.find<ProdukRekomendasiController>().getProdukRekomendasiList();
    await Get.find<ProdukPopulerController>().getProdukPopulerList();
  }

  @override
  void initState(){
    super.initState();
    _loadResource();
    controller = new AnimationController(vsync: this, duration: const Duration(seconds: 2))..forward();
    animation = new CurvedAnimation(parent: controller, curve: Curves.linear);
    Timer(
      const Duration(seconds: 5),
        ()=>Get.offNamed(PembantuRute.getInitial())
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: WarnaL.warnalogo,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          ScaleTransition( scale : animation,
            child: Center(
                child:
                Image.asset("assets/image/logo part 1.png", width : Dimensi.layar)),
          )
        ],
      )
    );
  }
}
