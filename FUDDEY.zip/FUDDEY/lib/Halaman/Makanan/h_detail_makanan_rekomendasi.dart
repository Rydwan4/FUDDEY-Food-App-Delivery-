import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tubes/Controllers/c_keranjang_controller.dart';
import 'package:tubes/Controllers/c_produk_rekomendasi_controller.dart';
import 'package:tubes/Halaman/home/h_halaman_utama.dart';
import 'package:tubes/komponen/k_dimensi.dart';
import 'package:tubes/widgets/w_kolom_dekorasi.dart';
import 'package:tubes/widgets/w_show_more_teks.dart';
import 'package:get/get.dart';

import '../../komponen/k_aplikasi_konstan.dart';
import '../../komponen/k_warna.dart';
import '../../rute/pembantu_rute.dart';
import '../../widgets/w_ikon_aplikasi.dart';
import '../../widgets/w_ikon_dan_teks_widget.dart';
import '../../widgets/w_teks_besar.dart';
import '../../widgets/w_teks_kecil.dart';
import '../keranjang/h_halaman_keranjang.dart';

class DetailMakananRekomendasi extends StatelessWidget {
  final int pageId;
  final String page;
  const DetailMakananRekomendasi({Key? key, required this.pageId, required this.page}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var produk= Get.find<ProdukRekomendasiController>().produkRekomendasiList[pageId];
    Get.find<ProdukRekomendasiController>().initProduk(produk,Get.find<KeranjangController>());
    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          //Gambar makanan
          Positioned(
            left: 0,
            right: 0,
            child: Container(
              width: double.maxFinite,
              height: Dimensi.popularFoodImgSize,
              decoration: BoxDecoration(
                image: DecorationImage(
                  fit: BoxFit.cover,
                  image: NetworkImage(
                    AplikasiKonstan.BASE_URL+AplikasiKonstan.UPLOAD_URL+produk.img!
                  )
                )
              ),
            )
          ),

          //Gambar ikon
          Positioned(
              top: Dimensi.height45,
              left: Dimensi.width20,
              right: Dimensi.width20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: (){
                    if(page=="halamankeranjang"){
                      Get.toNamed(PembantuRute.getHalamanKeranjang());
                    }else{
                      Get.toNamed(PembantuRute.getInitial());
                    }
                  },
                    child:
                IkonAplikasi(icon: Icons.arrow_back_ios)),
                GetBuilder<ProdukRekomendasiController>(builder: (controller){
                  return GestureDetector(
                    onTap:(){
                      if(controller.totalItems>=1)
                      Get.toNamed(PembantuRute.getHalamanKeranjang());
                    },
                    child: Stack(
                      children: [
                        IkonAplikasi(icon: Icons.shopping_cart_outlined),
                          controller.totalItems>=1?
                        Positioned(
                          right: 0, top:0,
                                child: IkonAplikasi(icon: Icons.circle, size: Dimensi.icon20, iconColor: Colors.transparent, backgroundColor: WarnaL.warnautama,)):Container(),
                        Get.find<ProdukRekomendasiController>().totalItems>=1?
                        Positioned(
                            right: 3, top:3,
                            child:
                            TeksBesar(text: Get.find<ProdukRekomendasiController>().totalItems.toString(), size : Dimensi.icon12, color: Colors.white,)):Container()
                      ],
                    ),
                  );
                })
              ],
          )),

          //Keterangan
          Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              top: Dimensi.popularFoodImgSize-20,
              child: Container(
              padding: EdgeInsets.only(left: Dimensi.width20, right: Dimensi.width20,top: Dimensi.height20),
                decoration: BoxDecoration(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(Dimensi.radius20),
                  topRight: Radius.circular(Dimensi.radius20),
                ),
                color: Colors.white,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    KolomDekorasi(teks: produk.name!),
                    SizedBox(height: Dimensi.height20),
                    TeksBesar(text: "Perkenalkan"),
                    SizedBox(height: Dimensi.height20),
                    Expanded(
                        child: SingleChildScrollView(
                          child: ShowMoreTeks(text: produk.description!)))
                  ],
                ),
          )),
        ],
      ),

      //Background tombol
      bottomNavigationBar: GetBuilder<ProdukRekomendasiController>(builder: (produkRekomendasi){
        return Container(
          height: Dimensi.bottomHeightBar,
          padding: EdgeInsets.only(top: Dimensi.height20, bottom: Dimensi.height20, left: Dimensi.width20, right: Dimensi.width20),
          decoration: BoxDecoration(
            color: WarnaL.warnabelakangtombol,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(Dimensi.radius30),
              topRight: Radius.circular(Dimensi.radius30),
            ),
          ),

          child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children:[
                //Ikon bawah
                Container(
                  padding: EdgeInsets.only(top: Dimensi.height15, bottom: Dimensi.height15, right: Dimensi.width20, left: Dimensi.width20),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(Dimensi.radius20),
                      color: WarnaL.warnautama
                  ),
                  child: Row(
                    children: [
                      GestureDetector(
                          onTap:  (){
                            produkRekomendasi.setQuantity(false);
                          },
                          child: Icon(Icons.remove, color : Colors.white)),
                      SizedBox(width: Dimensi.width10),
                      TeksBesar(text: produkRekomendasi.inBarangKeranjang.toString(),color: Colors.white,),
                      SizedBox(width: Dimensi.width10),
                      GestureDetector(
                          onTap:  (){
                            produkRekomendasi.setQuantity(true);
                          },
                          child: Icon(Icons.add, color : Colors.white)),
                    ],
                  ),
                ),

                //Keterangan Bawah
                GestureDetector(
                  onTap : (){
                  produkRekomendasi.addItem(produk);
                },
                  child: Container(
                    padding: EdgeInsets.only(top: Dimensi.height20, bottom: Dimensi.height15, right: Dimensi.width15, left: Dimensi.width20),
                      child: TeksBesar(text: "Rp. ${produk.price!} K | Tambah", color: Colors.white),
                        decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(Dimensi.radius20),
                        color: WarnaL.warnautama
                    ),
                  ),
                )
              ]
          ),
        );
      })
    );
  }
}
