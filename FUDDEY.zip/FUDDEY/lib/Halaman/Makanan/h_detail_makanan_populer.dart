import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tubes/Controllers/c_produk_populer_controller.dart';
import 'package:tubes/Controllers/c_produk_rekomendasi_controller.dart';
import 'package:tubes/komponen/k_dimensi.dart';
import 'package:tubes/komponen/k_warna.dart';
import 'package:tubes/rute/pembantu_rute.dart';
import 'package:tubes/widgets/w_ikon_aplikasi.dart';
import 'package:tubes/widgets/w_show_more_teks.dart';
import 'package:get/get.dart';

import '../../Controllers/c_keranjang_controller.dart';
import '../../komponen/k_aplikasi_konstan.dart';
import '../../widgets/w_teks_besar.dart';

class DetailMakananPopuler extends StatelessWidget {
  final int pageId;
  final String page;
  const DetailMakananPopuler({Key? key, required this.pageId, required this.page}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var produk = Get.find<ProdukPopulerController>().produkPopulerList[pageId];
    Get.find<ProdukRekomendasiController>().initProduk(produk,Get.find<KeranjangController>());
    return Scaffold(
      backgroundColor: Colors.white,
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            automaticallyImplyLeading: false,
            toolbarHeight: 70,
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: (){
                    if(page=="halamankeranjang"){
                      Get.toNamed(PembantuRute.getHalamanKeranjang());
                    }else{
                      Get.toNamed(PembantuRute.getInitial());
                    }
                    },
                  child: IkonAplikasi(icon: Icons.arrow_back_ios),
                ),
                //IkonAplikasi(icon: Icons.shopping_cart_outlined)
                GetBuilder<ProdukRekomendasiController>(builder: (controller){
                  return GestureDetector(
                      onTap:(){
                        if(controller.totalItems>=1)
                        Get.toNamed(PembantuRute.getHalamanKeranjang());
                  },
                    child: Stack(
                      children: [
                        IkonAplikasi(icon: Icons.shopping_cart_outlined),
                        Get.find<ProdukRekomendasiController>().totalItems>=1?
                        Positioned(
                            right: 0, top:0,

                                child: IkonAplikasi(icon: Icons.circle, size: Dimensi.icon20, iconColor: Colors.transparent, backgroundColor: WarnaL.warnautama,)):Container(),
                                Get.find<ProdukRekomendasiController>().totalItems>=1?
                                Positioned(
                                  right: 3, top:3,
                                  child:
                                  TeksBesar(text: Get.find<ProdukRekomendasiController>().totalItems.toString(), size : Dimensi.icon12, color: Colors.white,)):Container()
                      ],
                    ),
                  );
                })

              ],
            ),
            bottom: PreferredSize(
              preferredSize: Size.fromHeight(20),
              child: Container(
                child: Center(child: TeksBesar(size:Dimensi.font26,text:produk.name!)),
                width: double.maxFinite,
                padding: EdgeInsets.only(top: 5, bottom: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(Dimensi.radius20),
                    topRight: Radius.circular(Dimensi.radius20),
                  )
                ),
              ),
            ),
            pinned: true,
            backgroundColor: WarnaL.warnautama,
            expandedHeight: 300,
            flexibleSpace: FlexibleSpaceBar(
              background: Image.network(
                AplikasiKonstan.BASE_URL+AplikasiKonstan.UPLOAD_URL+produk.img!,
                width: double.maxFinite,
                fit: BoxFit.cover,
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Column(
              children:[
                Container(
                  child: ShowMoreTeks(text:produk.description!),
                  margin: EdgeInsets.only(left: Dimensi.width20, right: Dimensi.width20)
                )
              ]
            )
          ),
        ],
      ),
      bottomNavigationBar: GetBuilder<ProdukRekomendasiController>(builder:(controller){
        return Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: EdgeInsets.only(left: Dimensi.width20*2.5, right: Dimensi.width20*2.5, top: Dimensi.height10, bottom: Dimensi.height10,),
              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children:[
                    GestureDetector(
                      onTap: (){
                        controller.setQuantity(false);
                      },
                      child: IkonAplikasi(ukuranikon: Dimensi.icon24 ,iconColor: Colors.white, backgroundColor: WarnaL.warnautama,icon:Icons.remove),
                    ),
                    TeksBesar(text: "Rp.${produk.price!} K X  ${controller.inBarangKeranjang}"),
                    GestureDetector(
                      onTap: (){
                        controller.setQuantity(true);
                      },
                      child: IkonAplikasi(ukuranikon: Dimensi.icon24 ,iconColor: Colors.white, backgroundColor: WarnaL.warnautama,icon:Icons.add),
                    ),
                  ]
              ),
            ),
            Container(
              height: Dimensi.bottomHeightBar,
              padding: EdgeInsets.only(top: Dimensi.height20, bottom: Dimensi.height20, left: Dimensi.width20, right: Dimensi.width20),
              decoration: BoxDecoration(
                color: WarnaL.warnabelakangtombol,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(Dimensi.radius30),
                  topRight: Radius.circular(Dimensi.radius30),
                ),
              ),

              child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children:[
                    //Ikon bawah
                    Container(
                        padding: EdgeInsets.only(top: Dimensi.height15, bottom: Dimensi.height15, right: Dimensi.width20, left: Dimensi.width20),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(Dimensi.radius20),
                            color: WarnaL.warnautama
                        ),
                        child: Icon(
                          Icons.favorite,
                          color: Colors.white,
                        )
                    ),

                    //Keterangan Bawah
                    GestureDetector(
                      onTap: (){
                      controller.addItem(produk);
                    },
                      child: Container(
                        padding: EdgeInsets.only(top: Dimensi.height20, bottom: Dimensi.height15, right: Dimensi.width15, left: Dimensi.width20),
                        child: TeksBesar(text: "Rp. ${produk.price!}K |Tambah", color: Colors.white),
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(Dimensi.radius20),
                            color: WarnaL.warnautama
                        ),
                      ),
                    )
                  ]
              ),
            )
          ],
        );
      }),
    );
  }
}
