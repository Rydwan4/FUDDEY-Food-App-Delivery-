import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:tubes/Controllers/c_auth_controller.dart';
import 'package:tubes/komponen/k_warna.dart';
import 'package:tubes/model/signup_body_model.dart';
import 'package:tubes/widgets/w_aplikasi_text_field.dart';
import 'package:get/get.dart';

import '../../base/custom_loader.dart';
import '../../base/show_custom_pesan.dart';
import '../../komponen/k_dimensi.dart';
import '../../widgets/w_teks_besar.dart';

class HalamanSignUp extends StatelessWidget {
  const HalamanSignUp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var emailController = TextEditingController();
    var passwordController = TextEditingController();
    var nameController = TextEditingController();
    var phoneController = TextEditingController();
    var signUpImages =["t.png","f.png","g.png"];

    void _registrasi(AuthController authController){
      String nama = nameController.text.trim();
      String phone = phoneController.text.trim();
      String email = emailController.text.trim();
      String password = passwordController.text.trim();

      if(nama.isEmpty){
        showCustomPesan("Tulis Namamu", title: "Nama");
      }else if(phone.isEmpty){
        showCustomPesan("Tulis Nomormu", title: "Nomor Telepon");
      }else if(email.isEmpty){
        showCustomPesan("Tulis Emailmu", title: "Email");
      }else if(!GetUtils.isEmail(email)){
        showCustomPesan("Tulis Dengan Email Validmu", title: "Valid Email");
      }else if(password.isEmpty){
        showCustomPesan("Tulis Passwordmu", title: "Password");
      }else if(password.length<6){
        showCustomPesan("Password Tidak Bisa Kurang dari 6 Karakter", title: "Password");
      }else{
        showCustomPesan("Nice", title: "Mantap");
        SignUpBody signUpBody= SignUpBody(
            nama: nama,
            phone: phone,
            email: email,
            password: password);
        authController.registrasi(signUpBody).then((status){
          if(status.isSuccess){
            print("Success Registrasi");
          }else{
            showCustomPesan(status.message);
          }
        });
      }
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: GetBuilder<AuthController>(builder:(_authController){
        return !_authController.isLoading?SingleChildScrollView(
          physics: BouncingScrollPhysics(),
          child: Column(
              children: [
                SizedBox(height: Dimensi.screenHeight*0.05),
                Container(
                    height: Dimensi.screenHeight*0.25,
                    child: Center(
                      child: CircleAvatar(
                        backgroundColor: Colors.white,
                        radius: 80,
                        backgroundImage: AssetImage(
                            "assets/image/logo part 1.png"
                        ),
                      ),
                    )
                ),
                //email
                AplikasiTextField(
                    textController: emailController,
                    hintText: "Email",
                    icon: Icons.email),
                SizedBox(height: Dimensi.height20),
                //password
                AplikasiTextField(
                    textController: passwordController,
                    hintText: "Password",
                    icon: Icons.password_sharp, isObscure:true,),
                SizedBox(height: Dimensi.height20),
                //nama
                AplikasiTextField(
                    textController: nameController,
                    hintText: "Name",
                    icon: Icons.person),
                SizedBox(height: Dimensi.height20),
                //phone
                AplikasiTextField(
                    textController: phoneController,
                    hintText: "Phone",
                    icon: Icons.phone),
                SizedBox(height: Dimensi.height20*2),
                //tombol signup
                GestureDetector(
                  onTap: (){
                    _registrasi(_authController);
                  },
                  child: Container(
                      width: Dimensi.screenWidth/2,
                      height: Dimensi.screenHeight/13,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(Dimensi.radius30),
                          color: WarnaL.warnautama
                      ),
                      child: Center(
                        child: TeksBesar(
                          text: "Sign up",
                          size: Dimensi.font20*1.5,
                          color: Colors.white,
                        ),
                      )
                  ),
                ),
                SizedBox(height: Dimensi.height10),
                //tagline
                RichText(
                    text: TextSpan(
                        recognizer: TapGestureRecognizer()..onTap=()=>Get.back(),
                        text: "Sudah punya akun ?",
                        style: TextStyle(
                            color: Colors.grey[500],
                            fontSize: Dimensi.font20
                        )
                    )),
                SizedBox(height: Dimensi.screenHeight*0.04),
                //signup opsi
                RichText(
                    text: TextSpan(
                        text: "Pilih salah satu",
                        style: TextStyle(
                            color: Colors.grey[500],
                            fontSize: Dimensi.font16
                        )
                    )),
                Wrap(
                  children: List.generate(3, (index) => Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: CircleAvatar(
                      radius: Dimensi.radius30,
                      backgroundImage: AssetImage(
                          "assets/image/"+signUpImages[index]
                      ),
                    ),
                  )),
                )

              ]
          ),
        ):const CustomLoader();
      })
    );
  }
}
