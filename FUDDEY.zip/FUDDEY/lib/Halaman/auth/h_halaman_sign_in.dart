import 'package:flutter/cupertino.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:tubes/Halaman/auth/h_halaman_sign_up.dart';
import 'package:tubes/komponen/k_warna.dart';
import 'package:tubes/rute/pembantu_rute.dart';
import 'package:tubes/widgets/w_aplikasi_text_field.dart';
import 'package:get/get.dart';

import '../../Controllers/c_auth_controller.dart';
import '../../base/custom_loader.dart';
import '../../base/show_custom_pesan.dart';
import '../../komponen/k_dimensi.dart';
import '../../widgets/w_teks_besar.dart';

class HalamanSignIn extends StatelessWidget {
  const HalamanSignIn({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var emailController = TextEditingController();
    var passwordController = TextEditingController();
    void _login(AuthController authController){
      String email = emailController.text.trim();
      String password = passwordController.text.trim();

      if(email.isEmpty){
        showCustomPesan("Tulis Emailmu", title: "Email");
      }else if(!GetUtils.isEmail(email)){
        showCustomPesan("Tulis Dengan Email Validmu", title: "Valid Email");
      }else if(password.isEmpty){
        showCustomPesan("Tulis Passwordmu", title: "Password");
      }else if(password.length<6){
        showCustomPesan("Password Tidak Bisa Kurang dari 6 Karakter", title: "Password");
      }else{
        authController.login(email, password).then((status){
          if(status.isSuccess){
            Get.toNamed(PembantuRute.getInitial());
          }else{
            showCustomPesan(status.message);
          }
        });
      }
    }

    return Scaffold(
        backgroundColor: Colors.white,
        body: GetBuilder<AuthController>(builder: (authController){
          return !authController.isLoading? SingleChildScrollView(
            physics: BouncingScrollPhysics(),
            child: Column(
                children: [
                  SizedBox(height: Dimensi.screenHeight*0.05),
                  //Logo Apk
                  Container(
                      height: Dimensi.screenHeight*0.25,
                      child: Center(
                        child: CircleAvatar(
                          backgroundColor: Colors.white,
                          radius: 80,
                          backgroundImage: AssetImage(
                              "assets/image/logo part 1.png"
                          ),
                        ),
                      )
                  ),
                  //Salam
                  Container(
                    margin: EdgeInsets.only(left: Dimensi.width20),
                    width: double.maxFinite,
                    child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                              "Silahkan",
                              style: TextStyle(
                                fontSize: Dimensi.font20*3+Dimensi.font20/2,
                                fontWeight: FontWeight.bold,
                              )
                          ),
                          Text(
                              "Untuk Sign in",
                              style: TextStyle(
                                  fontSize: Dimensi.font20,
                                  color: Colors.grey[500]
                              )
                          )
                        ]
                    ),
                  ),
                  SizedBox(height: Dimensi.height20),
                  //email
                  AplikasiTextField(
                      textController: emailController,
                      hintText: "Email",
                      icon: Icons.email),
                  SizedBox(height: Dimensi.height20),
                  //password
                  AplikasiTextField(
                      textController: passwordController,
                      hintText: "Password",
                      icon: Icons.password_sharp, isObscure:true),
                  SizedBox(height: Dimensi.height10),
                  //tagline
                  Row(
                      children: [
                        Expanded(child: Container()),
                        RichText(
                            text: TextSpan(
                                text: "Sign in ke akunmu",
                                style: TextStyle(
                                    color: Colors.grey[500],
                                    fontSize: Dimensi.font20
                                )
                            )),
                        SizedBox(width: Dimensi.width20)
                      ]
                  ),
                  SizedBox(height: Dimensi.screenHeight*0.04),
                  //Sign in
                  GestureDetector(
                    onTap: (){
                      _login(authController);
                    },
                    child: Container(
                        width: Dimensi.screenWidth/2,
                        height: Dimensi.screenHeight/13,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(Dimensi.radius30),
                            color: WarnaL.warnautama
                        ),
                        child: Center(
                          child: TeksBesar(
                            text: "Sign in",
                            size: Dimensi.font20*1.5,
                            color: Colors.white,
                          ),
                        )
                    ),
                  ),
                  SizedBox(height: Dimensi.screenHeight*0.04),
                  //signup opsi
                  RichText(
                      text: TextSpan(
                          text: "Tidak punya akun ?",
                          style: TextStyle(
                              color: Colors.grey[500],
                              fontSize: Dimensi.font20
                          ),
                          children: [
                            TextSpan(
                                recognizer: TapGestureRecognizer()..onTap=()=>Get.to(()=>HalamanSignUp(), transition: Transition.fade,),
                                text: " Buat",
                                style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: WarnaL.warnautamahitam,
                                    fontSize: Dimensi.font20
                                )
                            )
                          ]
                      )
                  ),
                ]
            ),
          ):CustomLoader();
        })
    );
  }
}
