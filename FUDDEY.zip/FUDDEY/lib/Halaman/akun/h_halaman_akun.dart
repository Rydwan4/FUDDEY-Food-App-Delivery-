import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:tubes/rute/pembantu_rute.dart';
import 'package:tubes/widgets/w_ikon_aplikasi.dart';
import 'package:tubes/widgets/w_teks_besar.dart';
import 'package:get/get.dart';

import '../../komponen/k_dimensi.dart';
import '../../komponen/k_warna.dart';
import '../../widgets/w_akun_widget.dart';

class HalamanAkun extends StatelessWidget {
  const HalamanAkun({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: double.maxFinite,
              height: Dimensi.height30*10,
              margin: EdgeInsets.only(left: Dimensi.width20, right: Dimensi.width20),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(Dimensi.radius20),
                  image: DecorationImage(
                      fit:BoxFit.cover,
                      image: AssetImage(
                          "assets/image/signintocontinue.png"
                      )
                  )
              ),
            ),
            GestureDetector(
              onTap: (){
                Get.toNamed(PembantuRute.getHalamanSignIn());
              },
              child: Container(
                width: double.maxFinite,
                height: Dimensi.height20*5,
                margin: EdgeInsets.only(left: Dimensi.width20, right: Dimensi.width20),
                decoration: BoxDecoration(
                  color: WarnaL.warnautama,
                    borderRadius: BorderRadius.circular(Dimensi.radius20),
                ),
                child: Center(child: TeksBesar(text: "Sign In", color: Colors.white, size: Dimensi.font26)),
              ),
            ),
          ]
        )
      ),
      /*appBar: AppBar(
        backgroundColor: WarnaL.warnautama,
        title: TeksBesar(
          text: "Profile", size: 24, color: Colors.white,
        )
      ),
      body: Container(
        width: double.maxFinite,
        margin: EdgeInsets.only(top: Dimensi.height20),
        child: Column(

          children: [
            //Ikon Profile
            IkonAplikasi(icon: Icons.person,
            backgroundColor: WarnaL.warnautama,
              iconColor: Colors.white,
              ukuranikon: Dimensi.height15*5,
              size: Dimensi.height15*10),
            SizedBox(height: Dimensi.height30),

            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    //Nama
                    AkunWidget(
                      ikonAplikasi: IkonAplikasi(icon: Icons.person,
                          backgroundColor: WarnaL.warnautama,
                          iconColor: Colors.white,
                          ukuranikon: Dimensi.height10*5/2,
                          size: Dimensi.height10*5),
                      teksBesar: TeksBesar(text: "Rydwan"),
                    ),
                    SizedBox(height: Dimensi.height20),
                    //Phone
                    AkunWidget(
                      ikonAplikasi: IkonAplikasi(icon: Icons.phone,
                          backgroundColor: Colors.orange,
                          iconColor: Colors.white,
                          ukuranikon: Dimensi.height10*5/2,
                          size: Dimensi.height10*5),
                      teksBesar: TeksBesar(text: "0897654321"),
                    ),
                    SizedBox(height: Dimensi.height20),
                    //Email
                    AkunWidget(
                      ikonAplikasi: IkonAplikasi(icon: Icons.email,
                          backgroundColor: Colors.orange,
                          iconColor: Colors.white,
                          ukuranikon: Dimensi.height10*5/2,
                          size: Dimensi.height10*5),
                      teksBesar: TeksBesar(text: "Rydwan@gmail.com"),
                    ),
                    SizedBox(height: Dimensi.height20),
                    //Alamat
                    AkunWidget(
                      ikonAplikasi: IkonAplikasi(icon: Icons.location_on,
                          backgroundColor: Colors.orange,
                          iconColor: Colors.white,
                          ukuranikon: Dimensi.height10*5/2,
                          size: Dimensi.height10*5),
                      teksBesar: TeksBesar(text: "lokasimu"),
                    ),
                    SizedBox(height: Dimensi.height20),
                    //Pesan
                    AkunWidget(
                      ikonAplikasi: IkonAplikasi(icon: Icons.message_outlined,
                          backgroundColor: Colors.redAccent,
                          iconColor: Colors.white,
                          ukuranikon: Dimensi.height10*5/2,
                          size: Dimensi.height10*5),
                      teksBesar: TeksBesar(text: "Rydwan"),
                    ),
                    SizedBox(height: Dimensi.height20),
                  ],
                ),
              ),
            )
          ],
        ),
      ),*/
    );
  }
}
