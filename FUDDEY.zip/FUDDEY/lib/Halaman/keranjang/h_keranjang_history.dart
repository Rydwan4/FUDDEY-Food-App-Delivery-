import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:tubes/Controllers/c_keranjang_controller.dart';
import 'package:tubes/komponen/k_aplikasi_konstan.dart';
import 'package:tubes/komponen/k_dimensi.dart';
import 'package:tubes/komponen/k_warna.dart';
import 'package:tubes/rute/pembantu_rute.dart';
import 'package:tubes/widgets/w_ikon_aplikasi.dart';
import 'package:tubes/widgets/w_teks_besar.dart';
import 'package:get/get.dart';
import 'package:tubes/widgets/w_teks_kecil.dart';

import '../../base/tidak_ada_data.dart';
import '../../model/keranjang_model.dart';

class KeranjangHistory extends StatelessWidget {
  const KeranjangHistory({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var getKeranjangHistoryList = Get.find<KeranjangController>()
        .getKeranjangHistoryList().reversed.toList();

    Map<String, int> keranjangItemPerOrder = Map();

    for(int i=0; i<getKeranjangHistoryList.length; i++){
      if(keranjangItemPerOrder.containsKey(getKeranjangHistoryList[i].time)){
        keranjangItemPerOrder.update(getKeranjangHistoryList[i].time!, (value)=>++value);
      }else{
        keranjangItemPerOrder.putIfAbsent(getKeranjangHistoryList[i].time!,()=>1);
      }
    }

    List<int> keranjangItemsPerOrderToList(){
      return keranjangItemPerOrder.entries.map((e)=>e.value).toList();
    }
    List<String> keranjangOrderTimeToList(){
      return keranjangItemPerOrder.entries.map((e)=>e.key).toList();
    }

    List<int>itemsPerOrder = keranjangItemsPerOrderToList();
    var listCounter=0;
    Widget timeWidget(int index){
      var outputDate = DateTime.now().toString();
      if(index<getKeranjangHistoryList.length){
        DateTime parseDate = DateFormat("yyyy-MM-dd HH:mm:ss").parse(getKeranjangHistoryList[listCounter].time!);
        var inputDate = DateTime.parse(parseDate.toString());
        var outputFormat = DateFormat("dd/MM/yyyy hh:mm a");
        outputDate = outputFormat.format(inputDate);
      }
      return TeksBesar(text: outputDate);
    }

    return Scaffold(
      body:Column(
        children: [
          //Bagian atas
          Container(
            height: Dimensi.height10*10,
            color: WarnaL.warnautama,
            width: double.maxFinite,
            padding: EdgeInsets.only(top:Dimensi.height45),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                TeksBesar(text: "Keranjang History", color: Colors.white),
                IkonAplikasi(icon: Icons.shopping_cart_outlined,
                    iconColor: WarnaL.warnautama,
                    backgroundColor: Colors.white,
                )
              ],
            )
          ),
          //Body
          GetBuilder<KeranjangController>(builder: (_keranjangController){
            return _keranjangController.getKeranjangHistoryList().length>0?
            Expanded(child: Container(
                margin:EdgeInsets.only(top:Dimensi.height20, left: Dimensi.width20,right: Dimensi.width20),
                child: MediaQuery.removePadding(
                    removeTop: true,
                    context: context,
                    child: ListView(
                        children: [
                          for(int i=0; i<itemsPerOrder.length; i++)
                            Container(
                              height: Dimensi.height10*12,
                              margin: EdgeInsets.only(bottom: Dimensi.height20),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:[
                                    timeWidget(listCounter),
                                    SizedBox(height: Dimensi.height10),
                                    Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Wrap(
                                              direction: Axis.horizontal,
                                              children:List.generate(itemsPerOrder[i], (index){
                                                if(listCounter<getKeranjangHistoryList.length){
                                                  listCounter++;
                                                }
                                                return index<=2?Container(
                                                    height: Dimensi.height20*4,
                                                    width: Dimensi.width20*4,
                                                    margin: EdgeInsets.only(right: Dimensi.width10/2),
                                                    decoration: BoxDecoration(
                                                        borderRadius: BorderRadius.circular(Dimensi.radius15/2),
                                                        image: DecorationImage(
                                                            fit: BoxFit.cover,
                                                            image: NetworkImage(
                                                                AplikasiKonstan.BASE_URL+AplikasiKonstan.UPLOAD_URL+getKeranjangHistoryList[listCounter-1].img!
                                                            )
                                                        )
                                                    )
                                                ):Container();
                                              }
                                              )
                                          ),
                                          Container(
                                            height: Dimensi.height20*4,
                                            child: Column(
                                                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                crossAxisAlignment: CrossAxisAlignment.end,
                                                children: [
                                                  TeksKecil(text: "Total", color: WarnaL.warnajudul),
                                                  TeksBesar(text: itemsPerOrder[i].toString()+" Items", color: WarnaL.warnajudul,),
                                                  GestureDetector(
                                                    onTap: () {
                                                      var orderTime = keranjangOrderTimeToList();
                                                      Map<int, KeranjangModel> moreOrder = {};
                                                      for(int j=0; j<getKeranjangHistoryList.length; j++){
                                                        if(getKeranjangHistoryList[j].time==orderTime[i]){
                                                          moreOrder.putIfAbsent(getKeranjangHistoryList[j].id!, () =>
                                                              KeranjangModel.fromJson(jsonDecode(jsonEncode(getKeranjangHistoryList[j])))
                                                          );
                                                        }
                                                      }
                                                      Get.find<KeranjangController>().setItems= moreOrder;
                                                      Get.find<KeranjangController>().tambahKeranjangList();
                                                      Get.toNamed(PembantuRute.getHalamanKeranjang());
                                                    },
                                                    child: Container(
                                                        padding: EdgeInsets.symmetric(horizontal: Dimensi.width10,
                                                            vertical: Dimensi.height10/2),
                                                        decoration: BoxDecoration(
                                                          borderRadius: BorderRadius.circular(Dimensi.radius15/3),
                                                          border: Border.all(width: 1, color: WarnaL.warnautama),
                                                        ),
                                                        child: TeksKecil(text: "Satu Lagi",color: WarnaL.warnautama,)
                                                    ),
                                                  )
                                                ]
                                            ),
                                          )
                                        ]
                                    )
                                  ]
                              ),

                            )
                        ]
                    ))
            )):
            SizedBox(
              height : MediaQuery.of(context).size.height/1.5,
                child: const Center(
                  child: TidakAdaData(
                    text: "Kau belum membeli apapun !",
                    imgPath: "assets/image/empty_box.png"),
                ));
          }
          )
        ],
      )
    );
  }
}
