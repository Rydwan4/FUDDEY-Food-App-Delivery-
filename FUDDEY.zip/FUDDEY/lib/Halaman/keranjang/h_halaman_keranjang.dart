import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tubes/Controllers/c_auth_controller.dart';
import 'package:tubes/komponen/k_aplikasi_konstan.dart';
import 'package:tubes/komponen/k_warna.dart';
import 'package:tubes/widgets/w_ikon_aplikasi.dart';
import 'package:tubes/widgets/w_teks_besar.dart';
import 'package:tubes/widgets/w_teks_kecil.dart';

import '../../Controllers/c_keranjang_controller.dart';
import '../../Controllers/c_produk_populer_controller.dart';
import '../../Controllers/c_produk_rekomendasi_controller.dart';
import '../../base/tidak_ada_data.dart';
import '../../komponen/k_dimensi.dart';
import '../../rute/pembantu_rute.dart';

class HalamanKeranjang extends StatelessWidget {
  const HalamanKeranjang({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          //Header
          Positioned(
            left: Dimensi.width20,
            right: Dimensi.width20,
            top: Dimensi.height20*3,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: (){
                    Get.toNamed(PembantuRute.getInitial());
                  },
                  child: IkonAplikasi(icon: Icons.home_outlined,
                    iconColor: Colors.white,
                    backgroundColor: WarnaL.warnautama,
                    ukuranikon: Dimensi.icon24,
                  ),
                ),
                IkonAplikasi(icon: Icons.shopping_cart,
                  iconColor: Colors.white,
                  backgroundColor: WarnaL.warnautama,
                  ukuranikon: Dimensi.icon24,
                )
              ],

            )
          ),
          //Body
          GetBuilder<KeranjangController>(builder: (_keranjangController){
            return _keranjangController.getItems.length>0?Positioned(
                left: Dimensi.width20,
                right: Dimensi.width20,
                top: Dimensi.height20*5,
                bottom: 0,
                child: Container(
                  margin: EdgeInsets.only(top: Dimensi.height15),
                  child: MediaQuery.removePadding(
                    context: context,
                    removeTop: true,
                    child: GetBuilder<KeranjangController>(builder:(keranjangController){
                      var _keranjangList = keranjangController.getItems;
                      return ListView.builder(
                          itemCount: _keranjangList.length,
                          itemBuilder: (_, index){
                            return Container(
                                width: double.maxFinite,
                                height: Dimensi.height20*5,
                                child: Row(
                                    children: [
                                      GestureDetector(
                                        onTap: (){
                                          var rekomendasiIndex = Get.find<ProdukRekomendasiController>().produkRekomendasiList.indexOf(_keranjangList[index].produk!);
                                          if(rekomendasiIndex>=0){
                                            Get.toNamed(PembantuRute.getMakananRekomendasi(rekomendasiIndex,"halamankeranjang"));
                                          }else{
                                            var populerIndex = Get.find<ProdukPopulerController>().produkPopulerList.indexOf(_keranjangList[index].produk!);
                                            if(populerIndex<0){
                                              Get.snackbar("Riwayat Produk", "Ulasan produk tidak tersedia !",
                                                  backgroundColor: WarnaL.warnautama,
                                                  colorText: Colors.white
                                              );
                                            }else{
                                              Get.toNamed(PembantuRute.getMakananPopuler(populerIndex, "halamankeranjang"));
                                            }
                                          }
                                        },
                                        child:Container(
                                            height: Dimensi.height20*5,
                                            width: Dimensi.height20*5,
                                            margin: EdgeInsets.only(bottom: Dimensi.height10),
                                            decoration: BoxDecoration(
                                                image: DecorationImage(
                                                    fit: BoxFit.cover,
                                                    image: NetworkImage(
                                                        AplikasiKonstan.BASE_URL+AplikasiKonstan.UPLOAD_URL+keranjangController.getItems[index].img!
                                                    )
                                                ),
                                                borderRadius: BorderRadius.circular(Dimensi.radius20)

                                            )
                                        ),
                                      ),
                                      SizedBox(width: Dimensi.width10),
                                      Expanded(child: Container(
                                        height: Dimensi.height20*5,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                          children: [
                                            TeksBesar(text: keranjangController.getItems[index].name!, color: Colors.black,),
                                            TeksKecil(text: "Spicy"),
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                TeksBesar(text: "Rp. "+keranjangController.getItems[index]!.price.toString()+" K", color: Colors.black,),
                                                Container(
                                                  padding: EdgeInsets.only(top: Dimensi.height10, bottom: Dimensi.height10, right: Dimensi.width10, left: Dimensi.width10),
                                                  decoration: BoxDecoration(
                                                    borderRadius: BorderRadius.circular(Dimensi.radius20),
                                                  ),
                                                  child: Row(
                                                    children: [
                                                      GestureDetector(
                                                          onTap: (){
                                                            keranjangController.addItem(_keranjangList[index].produk!, -1);
                                                          },
                                                          child: Icon(Icons.remove, color : Colors.black)),
                                                      SizedBox(width: Dimensi.width10),
                                                      TeksBesar(text: _keranjangList[index].quantity.toString()),
                                                      SizedBox(width: Dimensi.width10),
                                                      GestureDetector(
                                                          onTap:  (){
                                                            keranjangController.addItem(_keranjangList[index].produk!, 1);
                                                          },
                                                          child: Icon(Icons.add, color : Colors.black)),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            )
                                          ],
                                        ),
                                      ))
                                    ]
                                )
                            );
                          });
                    }),
                  ),
                )):TidakAdaData(text: "Keranjangmu kosong !");
          })
        ]
      ),
        bottomNavigationBar: GetBuilder<KeranjangController>(builder: (keranjangController){
          return Container(
            height: Dimensi.bottomHeightBar,
            padding: EdgeInsets.only(top: Dimensi.height20, bottom: Dimensi.height20, left: Dimensi.width20, right: Dimensi.width20),
            decoration: BoxDecoration(
              color: WarnaL.warnabelakangtombol,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(Dimensi.radius30),
                topRight: Radius.circular(Dimensi.radius30),
              ),
            ),

            child: keranjangController.getItems.length>0?Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children:[
                //Ikon bawah
                Container(
                  padding: EdgeInsets.only(top: Dimensi.height15, bottom: Dimensi.height15, right: Dimensi.width20, left: Dimensi.width20),
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(Dimensi.radius20),
                      color: WarnaL.warnautama
                  ),
                  child: Row(
                    children: [
                      SizedBox(width: Dimensi.width10),
                      TeksBesar(text: "Rp. "+keranjangController.totalAmount.toString()+" K",color: Colors.white,),
                      SizedBox(width: Dimensi.width10),
                    ],
                  ),
                ),

                //Keterangan Bawah
                GestureDetector(
                  onTap : (){
                    if(Get.find<AuthController>().userLoggedIn()){
                    keranjangController.tambahKeHistory();
                    }else{
                      Get.toNamed(PembantuRute.getHalamanSignIn());
                    }
                },
                  child: Container(
                    padding: EdgeInsets.only(top: Dimensi.height20, bottom: Dimensi.height15, right: Dimensi.width15, left: Dimensi.width20),
                    child: TeksBesar(text: "Cek", color: Colors.white),
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(Dimensi.radius20),
                        color: WarnaL.warnautama
                    ),
                  ),
                )
              ]
          ):Container(),
          );
        })
    );
  }
}
