import 'dart:ui';

class WarnaL{
  static final Color warnateks = const Color(0xFFccc7c5);
  static final Color warnautama = const Color(0xffe3cb48);
  static final Color warnalogo = const Color(0xffffe01b);
  static final Color warnaicon1 = const Color(0xFFffd28d);
  static final Color warnaicon2 = const Color(0xFFfcab88);
  static final Color warnaicon3 = const Color(0xff48c5d7);
  static final Color warnapara = const Color(0xFF8f837f);
  static final Color warnabelakangtombol = const Color(0xffe7e7e7);
  static final Color warnatanda = const Color(0xff2c2a2a);
  static final Color warnajudul = const Color(0xFF5c524f);
  static final Color warnautamahitam = const Color(0xFF332d2b);
  static final Color warnakuning = const Color(0xFFffd379);
}