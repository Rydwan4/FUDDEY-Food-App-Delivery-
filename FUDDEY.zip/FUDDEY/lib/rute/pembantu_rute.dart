import 'package:get/get.dart';
import 'package:tubes/Halaman/Makanan/h_detail_makanan_populer.dart';
import 'package:tubes/Halaman/Makanan/h_detail_makanan_rekomendasi.dart';
import 'package:tubes/Halaman/Splash/h_halaman_splash.dart';
import 'package:tubes/Halaman/auth/h_halaman_sign_in.dart';
import '../Halaman/home/h_halaman_home.dart';
import '../Halaman/keranjang/h_halaman_keranjang.dart';

class PembantuRute{
  static const String halamansplash= "/splash-page";
  static const String initial= "/";
  static const String makananRekomendasi= "/makanan-rekomendasi";
  static const String makananPopuler= "/makanan-populer";
  static const String halamanKeranjang= "/keranjang";
  static const String signIn= "/sign-in";


  static String getHalamanSplash()=>'$halamansplash';
  static String getInitial()=>'$initial';
  static String getMakananRekomendasi(int pageId, String page)=> '$makananRekomendasi?pageId=$pageId&page=$page';
  static String getMakananPopuler(int pageId, String page)=> '$makananPopuler?pageId=$pageId&page=$page';
  static String getHalamanKeranjang()=>'$halamanKeranjang';
  static String getHalamanSignIn()=>'$signIn';

  static List<GetPage> rute=[
    GetPage(name: halamansplash, page: ()=>HalamanSplash()),
    GetPage(name: initial, page: (){

      return HalamanHome();
    }),
    GetPage(name: signIn, page: (){

      return HalamanSignIn();
    }, transition: Transition.fade),

    GetPage(name: makananRekomendasi, page: (){
      var pageId= Get.parameters['pageId'];
      var page= Get.parameters["page"];
      return DetailMakananRekomendasi(pageId:int.parse(pageId!),page:page!);
    },
      transition: Transition.rightToLeftWithFade
    ),
    GetPage(name: makananPopuler, page: (){
      var pageId= Get.parameters['pageId'];
      var page= Get.parameters["page"];
      return DetailMakananPopuler(pageId:int.parse(pageId!), page:page!);
    },
        transition: Transition.rightToLeftWithFade
    ),
    GetPage(name: halamanKeranjang, page: (){
      return HalamanKeranjang();
    },
        transition: Transition.leftToRightWithFade
    )
  ];
}