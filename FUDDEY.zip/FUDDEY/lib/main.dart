import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:tubes/Controllers/c_keranjang_controller.dart';
import 'package:tubes/Controllers/c_produk_rekomendasi_controller.dart';
import 'package:tubes/Halaman/Makanan/h_detail_makanan_populer.dart';
import 'package:tubes/rute/pembantu_rute.dart';
import 'Controllers/c_produk_populer_controller.dart';
import 'Halaman/Makanan/h_detail_makanan_rekomendasi.dart';
import 'Halaman/Splash/h_halaman_splash.dart';
import 'Halaman/auth/h_halaman_sign_in.dart';
import 'Halaman/auth/h_halaman_sign_up.dart';
import 'Halaman/home/h_halaman_makanan.dart';
import 'Halaman/home/h_halaman_utama.dart';
import 'package:tubes/Pembantu/dependencies.dart' as dep;

import 'Halaman/keranjang/h_halaman_keranjang.dart';

Future<void> main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await dep.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
  Get.find<KeranjangController>().getKeranjangData();
    return GetBuilder<ProdukRekomendasiController>(builder: (_){
      return GetBuilder<ProdukPopulerController>(builder: (_){
        return GetMaterialApp(
          debugShowCheckedModeBanner: false,
          //home: HalamanSignIn()
          initialRoute : PembantuRute.getHalamanSplash(),
          getPages: PembantuRute.rute,
        );
      });
    });
  }
}
