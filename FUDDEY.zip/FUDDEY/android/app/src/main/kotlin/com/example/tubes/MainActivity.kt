package com.example.tubes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
